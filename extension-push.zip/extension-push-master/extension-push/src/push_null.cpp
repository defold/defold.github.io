#if !defined(DM_PLATFORM_ANDROID) && !defined(DM_PLATFORM_IOS)
extern "C" void PushExtExternal()
{

}
#endif

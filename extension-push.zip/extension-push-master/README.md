# Push Notifications for Defold

Defold [native extension](https://www.defold.com/manuals/extensions/) for Push Notifications functionality on iOS and Android devices.

[Manual, API and setup instructions](https://www.defold.com/extension-push/) is available on the official Defold site.
